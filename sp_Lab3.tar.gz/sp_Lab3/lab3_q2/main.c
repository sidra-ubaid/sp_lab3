#include<stdio.h>
#include "myStr.h"
//#include<myStrFunc.c>

int main()
{
	char arr[]="abba";
	if(isPalindrome(arr,4)==1)
{
	printf("\nGiven string is Palindrome.\n");
}
	else
{
	printf("\nGiven string is not Palindrome.\n");
}
	char arr1[]="sidra";
	if(isPalindrome(arr1,5)==1)
{
	printf("\nGiven string is Palindrome.\n");
}
	else
{
	printf("\nGiven string is not Palindrome.\n");
}
	
	return 0;
}
