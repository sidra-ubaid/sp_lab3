#include<stdio.h>
int isPalindrome(char * arr,int size)
{
	int i;
	int ret=-1;
	
	for(i=0;i<size;i++)
	{
		if((arr[0+i]!=arr[(size-1)-i]))
		{
		ret=-1;
		break;
		}
		else
		{
		ret=1;
		}
	}

return ret;
}
