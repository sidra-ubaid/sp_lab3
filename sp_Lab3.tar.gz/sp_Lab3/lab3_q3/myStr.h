
int isPalindrome(char * arr,int size);
