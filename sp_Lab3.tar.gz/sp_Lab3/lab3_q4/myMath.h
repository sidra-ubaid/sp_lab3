
int isqual(int x,int y);
void swap(int a,int b);
