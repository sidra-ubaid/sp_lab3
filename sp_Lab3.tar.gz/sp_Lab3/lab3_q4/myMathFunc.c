#include<stdio.h>

int isequal(int x,int y)
{
	if(x==y)
	{
		printf("\nBoth numbers are equal.\n");
		return 1;
	}
	else
	{
		printf("\nBoth numbers are not equal.\n");
		return -1;
	
	}
	
}

void swap(int a,int b)
{
	//printf("\nNumbers before swap a=%d b=%d",a,b);
	//a=a+b;
	//b=a-b;
	//a=a-b;
	//printf("\nNumbers after swap a=%d b=%d",a,b);
	//printf("\n");
//printf("\ndefinition of swap function is changed\n");
printf("\nnew function is changed\n");
	

}
