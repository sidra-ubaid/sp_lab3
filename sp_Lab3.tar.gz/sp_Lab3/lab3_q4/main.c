#include<stdio.h>
#include "myMath.h"
//#include "myStr.h"
//#include "myMathFunc.c"

int main()
{
	int a=0;
	int b=0;
	printf("Enter value of a :");
	scanf("%d",&a);
	printf("Enter value of b :");
	scanf("%d",&b);
	isequal(a,b);
	swap(a,b);
return 0;
}
